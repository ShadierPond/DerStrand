Hallo,
Meine aufabe im projekt war die Propertys einzurichten und zu verbinden.
Ausßerdemhabe ich die Icons für das Menu gezeichnet sowie auch die Icons für die Propertys.
Ansonsten war ich für den Map aufbau und die Gestaltung verantwortlich.
Also Map Aufbau, die Texturen aufbringen, aufbau der Base Camps, Plazierung der Fallen und Büsche

Alle Items Importiert und fehler behoben falls vorhanden alle items mit mesh colider und rigedbody versehen und mit dem script Item Object versehen, 
den Item typ und den amaunt eingestellt.
Alle Plazierbaren Elemente Importiert und für das Bauen vorbereitet.
Alle Items im Ordner Assets/Prefabs sortiert und eingerichtet.
Alle Items im Ordner Assets/Resources/Items/Prefabs sortiert und bearbeitet.
Scripte die ich geschrieben habe aber nicht verwendet wurden waren: ObjectGrabbable,PlayerPickUpDrop